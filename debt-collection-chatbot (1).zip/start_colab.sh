#!/bin/bash
echo "🤖 Starting DebtBot AI in Google Colab"
echo "🐍 100% Pure Python Implementation"
echo "❌ NO Node.js | NO Express.js"
echo ""

# Install requirements
python colab_setup.py

# Start the server
echo "🚀 Starting FastAPI server..."
python main.py
