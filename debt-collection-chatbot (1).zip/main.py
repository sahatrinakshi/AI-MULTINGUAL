#!/usr/bin/env python3
"""
AI Debt Collection Chatbot - Complete Python Implementation
Designed for Google Colab deployment
"""

import os
import asyncio
import json
import logging
import uuid
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any
from dataclasses import dataclass
import sqlite3
import threading
import time

# Web framework
from fastapi import FastAPI, HTTPException, WebSocket, WebSocketDisconnect, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
import uvicorn

# HTTP client
import httpx

# Environment and configuration
from pydantic import BaseModel, Field
from pydantic_settings import BaseSettings

# Language processing
import re
from googletrans import Translator
from langdetect import detect
import sys

# Logging setup
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# =============================================================================
# CONFIGURATION
# =============================================================================

class Settings(BaseSettings):
    # WhatsApp Business API
    WHATSAPP_ACCESS_TOKEN: str = os.getenv("WHATSAPP_ACCESS_TOKEN", "EAAIrYgZBTkUsBO4Fi5uTUP2FEhpLKor9wQo6TyplVqZCVBNo8gkzydLq7JDlWGENZAfcG4u6vKTzyJBhMhmSsV9WSubrW6gAsSxZAhsZB5hKzGk4ToWVIJFazEzlYAYLJlSC8sKxsAAXKAFf9JYPMGUhxNCZAO5BobVsrfTDLelvvkk7O5545Mg2AZBiVD8TsOz7ezZC6TZAC7TCiMisnmam4qu196DPut1CYW5ikiZC4wqrusWMsZD")
    WHATSAPP_PHONE_NUMBER_ID: str = os.getenv("WHATSAPP_PHONE_NUMBER_ID", "674138942450620")
    WHATSAPP_VERIFY_TOKEN: str = os.getenv("WHATSAPP_VERIFY_TOKEN", "debt_collection_webhook_verify_2024")
    
    # AI Services
    XAI_API_KEY: Optional[str] = os.getenv("XAI_API_KEY", None)
    GROQ_API_KEY: Optional[str] = os.getenv("GROQ_API_KEY", None)
    
    # Application
    APP_NAME: str = os.getenv("APP_NAME", "DebtBot AI")
    VERSION: str = os.getenv("VERSION", "1.0.0")
    DEBUG: bool = True
    
    # Compliance
    RBI_COMPLIANCE_MODE: bool = True
    MAX_MESSAGES_PER_DAY: int = 3
    BUSINESS_HOURS_START: str = "09:00"
    BUSINESS_HOURS_END: str = "18:00"
    
    # Supported Languages
    SUPPORTED_LANGUAGES: list = ["hi", "mr", "ta", "te", "en", "en-IN"]

settings = Settings()

# =============================================================================
# DATA MODELS
# =============================================================================

@dataclass
class Borrower:
    id: str
    account_number: str
    name: str
    phone: str
    email: Optional[str]
    preferred_language: str
    outstanding_amount: float
    due_date: str
    status: str

@dataclass
class ChatSession:
    id: str
    borrower_id: str
    session_token: str
    platform: str
    language: str
    status: str
    started_at: str

@dataclass
class ConversationMessage:
    id: str
    session_id: str
    sender_type: str
    content: str
    language: str
    sent_at: str
    metadata: Dict

# Pydantic models for API
class ChatMessageRequest(BaseModel):
    session_token: str
    message: str
    language: Optional[str] = None

class ChatMessageResponse(BaseModel):
    success: bool
    response: str
    language: str
    intent: Optional[str] = None
    suggested_actions: List[str] = []
    session_token: str

class ChatSessionCreate(BaseModel):
    phone: Optional[str] = None
    account_number: Optional[str] = None
    platform: str = "web"
    language: Optional[str] = None

# =============================================================================
# DATABASE (SQLite for Colab)
# =============================================================================

class Database:
    def __init__(self, db_path: str = "debtbot.db"):
        self.db_path = db_path
        self.init_database()
    
    def init_database(self):
        """Initialize SQLite database with required tables"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Borrowers table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS borrowers (
                id TEXT PRIMARY KEY,
                account_number TEXT UNIQUE NOT NULL,
                name TEXT NOT NULL,
                phone TEXT NOT NULL,
                email TEXT,
                preferred_language TEXT DEFAULT 'hi',
                outstanding_amount REAL NOT NULL,
                due_date TEXT NOT NULL,
                status TEXT DEFAULT 'active',
                created_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        # Chat sessions table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS chat_sessions (
                id TEXT PRIMARY KEY,
                borrower_id TEXT NOT NULL,
                session_token TEXT UNIQUE NOT NULL,
                platform TEXT NOT NULL,
                language TEXT NOT NULL,
                status TEXT DEFAULT 'active',
                started_at TEXT DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (borrower_id) REFERENCES borrowers (id)
            )
        ''')
        
        # Conversation messages table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS conversation_messages (
                id TEXT PRIMARY KEY,
                session_id TEXT NOT NULL,
                sender_type TEXT NOT NULL,
                content TEXT NOT NULL,
                language TEXT,
                sent_at TEXT DEFAULT CURRENT_TIMESTAMP,
                metadata TEXT,
                FOREIGN KEY (session_id) REFERENCES chat_sessions (id)
            )
        ''')
        
        # Insert sample data
        cursor.execute('''
            INSERT OR IGNORE INTO borrowers 
            (id, account_number, name, phone, outstanding_amount, due_date, status)
            VALUES 
            ('1', 'AC123456789', 'राम शर्मा', '+919876543210', 25000.00, '2024-02-15', 'overdue'),
            ('2', 'AC987654321', 'सुनीता पटेल', '+919876543211', 15000.00, '2024-03-01', 'active'),
            ('3', 'AC456789123', 'अमित कुमार', '+919876543212', 35000.00, '2024-01-30', 'overdue')
        ''')
        
        conn.commit()
        conn.close()
        logger.info("Database initialized successfully")
    
    def get_connection(self):
        return sqlite3.connect(self.db_path)
    
    def get_borrower_by_phone(self, phone: str) -> Optional[Borrower]:
        """Get borrower by phone number"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        # Format phone number
        formatted_phone = phone.replace('+', '').replace('-', '').replace(' ', '')
        if formatted_phone.startswith('91') and len(formatted_phone) == 12:
            formatted_phone = formatted_phone[2:]
        
        cursor.execute('''
            SELECT id, account_number, name, phone, email, preferred_language, 
                   outstanding_amount, due_date, status
            FROM borrowers 
            WHERE phone LIKE ?
        ''', (f'%{formatted_phone}%',))
        
        row = cursor.fetchone()
        conn.close()
        
        if row:
            return Borrower(
                id=row[0], account_number=row[1], name=row[2], phone=row[3],
                email=row[4], preferred_language=row[5], outstanding_amount=row[6],
                due_date=row[7], status=row[8]
            )
        return None
    
    def create_chat_session(self, borrower_id: str, platform: str, language: str) -> ChatSession:
        """Create new chat session"""
        session_id = str(uuid.uuid4())
        session_token = f"session_{uuid.uuid4().hex[:16]}"
        
        conn = self.get_connection()
        cursor = conn.cursor()
        
        cursor.execute('''
            INSERT INTO chat_sessions (id, borrower_id, session_token, platform, language)
            VALUES (?, ?, ?, ?, ?)
        ''', (session_id, borrower_id, session_token, platform, language))
        
        conn.commit()
        conn.close()
        
        return ChatSession(
            id=session_id,
            borrower_id=borrower_id,
            session_token=session_token,
            platform=platform,
            language=language,
            status='active',
            started_at=datetime.now().isoformat()
        )
    
    def get_session_by_token(self, session_token: str) -> Optional[ChatSession]:
        """Get chat session by token"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        cursor.execute('''
            SELECT id, borrower_id, session_token, platform, language, status, started_at
            FROM chat_sessions 
            WHERE session_token = ?
        ''', (session_token,))
        
        row = cursor.fetchone()
        conn.close()
        
        if row:
            return ChatSession(
                id=row[0], borrower_id=row[1], session_token=row[2],
                platform=row[3], language=row[4], status=row[5], started_at=row[6]
            )
        return None
    
    def save_message(self, session_id: str, sender_type: str, content: str, 
                    language: str, metadata: Dict = None) -> str:
        """Save conversation message"""
        message_id = str(uuid.uuid4())
        
        conn = self.get_connection()
        cursor = conn.cursor()
        
        cursor.execute('''
            INSERT INTO conversation_messages 
            (id, session_id, sender_type, content, language, metadata)
            VALUES (?, ?, ?, ?, ?, ?)
        ''', (message_id, session_id, sender_type, content, language, 
              json.dumps(metadata or {})))
        
        conn.commit()
        conn.close()
        
        return message_id

# =============================================================================
# LANGUAGE SERVICE
# =============================================================================

class LanguageService:
    def __init__(self):
        self.translator = Translator()
        self.supported_languages = {
            'hi': 'Hindi',
            'mr': 'Marathi', 
            'ta': 'Tamil',
            'te': 'Telugu',
            'en': 'English',
            'en-IN': 'Hinglish'
        }
        
        # Language patterns for better detection
        self.language_patterns = {
            'hi': [
                r'[\u0900-\u097F]',  # Devanagari script
                r'\b(है|हैं|का|की|के|में|से|को|पर|और|या|नहीं|भी|तो|ही|जो|वह|यह|मैं|तुम|आप)\b'
            ],
            'mr': [
                r'[\u0900-\u097F]',  # Devanagari script
                r'\b(आहे|होते|करतो|मराठी|महाराष्ट्र|मुंबई)\b'
            ],
            'ta': [
                r'[\u0B80-\u0BFF]',  # Tamil script
                r'\b(இருக்கிறது|செய்கிறது|தமிழ்|நான்|நீங்கள்)\b'
            ],
            'te': [
                r'[\u0C00-\u0C7F]',  # Telugu script
                r'\b(ఉంది|చేస్తున్నాను|తెలుగు|నేను|మీరు)\b'
            ],
            'en-IN': [
                r'\b(hai|hain|kar|kya|aap|main|hum|paisa|rupee|payment|amount)\b',
                r'\b(chahiye|karna|kaise|kyun|abhi|jaldi|please)\b'
            ]
        }

    def detect_language(self, text: str) -> str:
        """Detect language of input text"""
        try:
            # Clean text
            cleaned_text = re.sub(r'[^\w\s]', ' ', text.lower())
            
            # Check for script-based patterns first
            for lang_code, patterns in self.language_patterns.items():
                for pattern in patterns:
                    if re.search(pattern, text, re.IGNORECASE):
                        if lang_code == 'hi' and self._is_marathi(text):
                            return 'mr'
                        return lang_code
            
            # Fallback to langdetect
            detected = detect(cleaned_text)
            
            # Map detected language to supported languages
            if detected in self.supported_languages:
                return detected
            elif detected == 'hi':
                return 'hi'
            elif detected == 'mr':
                return 'mr'
            else:
                return 'en'  # Default to English
                
        except Exception as e:
            logger.error(f"Language detection error: {e}")
            return 'en'  # Default fallback

    def _is_marathi(self, text: str) -> bool:
        """Check if Devanagari text is Marathi"""
        marathi_words = ['आहे', 'होते', 'करतो', 'मराठी', 'महाराष्ट्र']
        hindi_words = ['है', 'था', 'करता', 'हिंदी', 'भारत']
        
        marathi_count = sum(1 for word in marathi_words if word in text)
        hindi_count = sum(1 for word in hindi_words if word in text)
        
        return marathi_count > hindi_count

    def translate_text(self, text: str, target_language: str, source_language: str = None) -> Dict:
        """Translate text to target language"""
        try:
            if source_language == target_language:
                return {
                    'translated_text': text,
                    'source_language': source_language,
                    'target_language': target_language,
                    'confidence': 1.0
                }
            
            # Handle Hinglish specially
            if target_language == 'en-IN':
                return self._generate_hinglish(text, source_language)
            
            # Use Google Translate
            result = self.translator.translate(
                text, 
                dest=target_language, 
                src=source_language
            )
            
            return {
                'translated_text': result.text,
                'source_language': result.src,
                'target_language': target_language,
                'confidence': 0.9
            }
            
        except Exception as e:
            logger.error(f"Translation error: {e}")
            return {
                'translated_text': text,
                'source_language': source_language or 'unknown',
                'target_language': target_language,
                'confidence': 0.0
            }

    def _generate_hinglish(self, text: str, source_language: str) -> Dict:
        """Generate Hinglish text"""
        hinglish_mappings = {
            'payment': 'payment',
            'amount': 'amount',
            'due': 'due',
            'please': 'please',
            'thank you': 'thank you',
            'hello': 'hello',
            'yes': 'haan',
            'no': 'nahi',
            'money': 'paisa',
            'time': 'time',
            'today': 'aaj',
            'tomorrow': 'kal',
            'help': 'help',
            'problem': 'problem'
        }
        
        # Simple Hinglish generation
        hinglish_text = text
        for eng, hin in hinglish_mappings.items():
            hinglish_text = re.sub(rf'\b{eng}\b', hin, hinglish_text, flags=re.IGNORECASE)
        
        return {
            'translated_text': hinglish_text,
            'source_language': source_language,
            'target_language': 'en-IN',
            'confidence': 0.8
        }

# =============================================================================
# AI SERVICE
# =============================================================================

class AIService:
    def __init__(self):
        self.system_prompts = {
            'hi': """आप एक पेशेवर और सहानुभूतिपूर्ण ऋण वसूली AI सहायक हैं।

महत्वपूर्ण दिशानिर्देश:
- हमेशा सम्मानजनक, पेशेवर और RBI दिशानिर्देशों का अनुपालन करें
- कभी भी आक्रामक, धमकी भरा या परेशान करने वाला न हों
- पारस्परिक रूप से लाभकारी समाधान खोजने पर ध्यान दें
- भुगतान योजना, EMI विकल्प और निपटान चर्चा की पेशकश करें
- भारतीय संदर्भ के लिए सांस्कृतिक रूप से संवेदनशील रहें

आपका लक्ष्य ग्राहक संबंधों को बनाए रखते हुए ऋण वसूली करना है।""",

            'en': """You are a professional, empathetic debt collection AI assistant for India.

IMPORTANT GUIDELINES:
- Always be respectful, professional, and compliant with RBI guidelines
- Never be aggressive, threatening, or harassing
- Focus on finding mutually beneficial solutions
- Offer payment plans, EMI options, and settlement discussions
- Be culturally sensitive and appropriate for Indian context

Your goal is to recover debt while maintaining customer relationships.""",

            'en-IN': """Aap ek professional aur empathetic debt collection AI assistant hain.

IMPORTANT GUIDELINES:
- Hamesha respectful, professional aur RBI compliant rahiye
- Kabhi bhi aggressive ya threatening na baniye
- Mutually beneficial solutions dhundne par focus kariye
- Payment plans, EMI options offer kariye
- Indian context ke liye culturally appropriate rahiye

Aapka goal hai debt recover karna while maintaining good relationships."""
        }

    async def generate_response(
        self, 
        message: str, 
        borrower: Borrower, 
        conversation_history: List[Dict] = None,
        detected_language: str = 'en'
    ) -> Dict:
        """Generate AI response based on user message and context"""
        try:
            # Get appropriate system prompt
            system_prompt = self._get_system_prompt(detected_language, borrower)
            
            # Generate response using fallback method (since no API keys in Colab)
            response = await self._generate_fallback_response(
                message, borrower, detected_language
            )
            
            # Extract intent and entities
            intent = await self._extract_intent(message, detected_language)
            entities = await self._extract_entities(message)
            
            return {
                'content': response,
                'language': detected_language,
                'intent': intent,
                'entities': entities,
                'confidence': 0.9,
                'suggested_actions': self._get_suggested_actions(intent, borrower)
            }
            
        except Exception as e:
            logger.error(f"AI response generation error: {e}")
            return await self._generate_fallback_response(message, borrower, detected_language)

    def _get_system_prompt(self, language: str, borrower: Borrower) -> str:
        """Get system prompt for the given language"""
        base_prompt = self.system_prompts.get(language, self.system_prompts['en'])
        
        context = f"""
BORROWER INFORMATION:
- Name: {borrower.name}
- Account: {borrower.account_number}
- Outstanding Amount: ₹{borrower.outstanding_amount:,.2f}
- Due Date: {borrower.due_date}
- Status: {borrower.status}

COMPLIANCE REQUIREMENTS:
- Never threaten legal action unless authorized
- Always offer reasonable payment options
- Respect opt-out requests
- Maintain professional tone
- Document all interactions
"""
        
        return f"{base_prompt}\n\n{context}"

    async def _generate_fallback_response(self, message: str, borrower: Borrower, language: str) -> str:
        """Generate fallback response when AI service is unavailable"""
        name = borrower.name
        amount = borrower.outstanding_amount
        
        # Detect intent for better responses
        intent = await self._extract_intent(message, language)
        
        fallback_responses = {
            'hi': {
                'payment_inquiry': f"नमस्ते {name}! आपका बकाया राशि ₹{amount:,.2f} है। क्या आप भुगतान के विकल्पों के बारे में जानना चाहते हैं?",
                'payment_promise': f"धन्यवाद {name}! आपका भुगतान का वादा सराहनीय है। कृपया बताएं कि आप कब भुगतान कर सकते हैं?",
                'hardship': f"{name}, मैं आपकी स्थिति समझ सकता हूं। हम EMI या आंशिक भुगतान की योजना पर चर्चा कर सकते हैं।",
                'general_inquiry': f"नमस्ते {name}! मैं आपकी सहायता करने के लिए यहाँ हूँ। आपका बकाया राशि ₹{amount:,.2f} है। कैसे मदद कर सकता हूँ?"
            },
            'en': {
                'payment_inquiry': f"Hello {name}! Your outstanding amount is ₹{amount:,.2f}. Would you like to know about payment options?",
                'payment_promise': f"Thank you {name}! I appreciate your commitment to pay. When can you make the payment?",
                'hardship': f"{name}, I understand your situation. We can discuss EMI or partial payment plans.",
                'general_inquiry': f"Hello {name}! I'm here to help you. Your outstanding amount is ₹{amount:,.2f}. How can I assist you today?"
            },
            'en-IN': {
                'payment_inquiry': f"Hello {name}! Aapka outstanding amount ₹{amount:,.2f} hai. Payment options ke baare mein jaanna chahte hain?",
                'payment_promise': f"Thank you {name}! Aapka payment promise achha hai. Kab payment kar sakte hain?",
                'hardship': f"{name}, main aapki situation samajh sakta hun. EMI ya partial payment plan discuss kar sakte hain.",
                'general_inquiry': f"Hello {name}! Main aapki help karne ke liye yahan hun. Outstanding amount ₹{amount:,.2f} hai. Kaise help kar sakta hun?"
            }
        }
        
        responses = fallback_responses.get(language, fallback_responses['en'])
        return responses.get(intent, responses['general_inquiry'])

    async def _extract_intent(self, message: str, language: str) -> str:
        """Extract intent from user message"""
        message_lower = message.lower()
        
        intent_keywords = {
            'payment_inquiry': ['payment', 'pay', 'amount', 'due', 'भुगतान', 'पैसा', 'रकम', 'पेमेंट', 'kitna', 'कितना'],
            'payment_promise': ['will pay', 'can pay', 'tomorrow', 'next week', 'भुगतान करूंगा', 'पैसे दूंगा', 'kal', 'agle'],
            'dispute': ['wrong', 'mistake', 'not mine', 'dispute', 'गलत', 'गलती', 'galat'],
            'hardship': ['problem', 'difficulty', 'job loss', 'medical', 'समस्या', 'परेशानी', 'problem', 'mushkil'],
            'settlement': ['settle', 'discount', 'reduce', 'समझौता', 'कम', 'settlement'],
            'emi_request': ['installment', 'emi', 'monthly', 'किस्त', 'मासिक', 'monthly']
        }
        
        for intent, keywords in intent_keywords.items():
            if any(keyword in message_lower for keyword in keywords):
                return intent
        
        return 'general_inquiry'

    async def _extract_entities(self, message: str) -> Dict:
        """Extract entities from user message"""
        entities = {}
        
        # Extract amounts
        amount_pattern = r'₹?(\d+(?:,\d+)*(?:\.\d{2})?)'
        amounts = re.findall(amount_pattern, message)
        if amounts:
            entities['amounts'] = [float(amount.replace(',', '')) for amount in amounts]
        
        # Extract dates
        date_pattern = r'(\d{1,2}[-/]\d{1,2}[-/]\d{2,4})|tomorrow|next week|अगले सप्ताह|कल|kal'
        dates = re.findall(date_pattern, message, re.IGNORECASE)
        if dates:
            entities['dates'] = dates
        
        # Extract phone numbers
        phone_pattern = r'(\+91|91)?[-\s]?[6-9]\d{9}'
        phones = re.findall(phone_pattern, message)
        if phones:
            entities['phone_numbers'] = phones
        
        return entities

    def _get_suggested_actions(self, intent: str, borrower: Borrower) -> List[str]:
        """Get suggested actions based on intent"""
        action_map = {
            'payment_inquiry': ['show_payment_options', 'calculate_interest', 'payment_history'],
            'payment_promise': ['schedule_followup', 'send_payment_link', 'confirm_amount'],
            'dispute': ['escalate_to_agent', 'request_documents', 'schedule_call'],
            'hardship': ['offer_emi_plan', 'discuss_settlement', 'financial_counseling'],
            'settlement': ['calculate_settlement', 'get_approval', 'generate_offer'],
            'emi_request': ['calculate_emi', 'show_emi_options', 'setup_autopay']
        }
        
        return action_map.get(intent, ['general_assistance', 'escalate_to_agent'])

# =============================================================================
# WHATSAPP SERVICE
# =============================================================================

class WhatsAppService:
    def __init__(self):
        self.base_url = "https://graph.facebook.com/v18.0"
        self.phone_number_id = settings.WHATSAPP_PHONE_NUMBER_ID
        self.access_token = settings.WHATSAPP_ACCESS_TOKEN
        
        self.headers = {
            "Authorization": f"Bearer {self.access_token}",
            "Content-Type": "application/json"
        }

    async def send_message(self, to: str, message: str, message_type: str = "text") -> Dict:
        """Send WhatsApp message"""
        try:
            # Format phone number
            formatted_phone = self._format_phone_number(to)
            
            payload = {
                "messaging_product": "whatsapp",
                "to": formatted_phone,
                "type": message_type,
                "text": {
                    "body": message,
                    "preview_url": False
                }
            }
            
            async with httpx.AsyncClient() as client:
                response = await client.post(
                    f"{self.base_url}/{self.phone_number_id}/messages",
                    headers=self.headers,
                    json=payload
                )
                
                if response.status_code == 200:
                    result = response.json()
                    logger.info(f"WhatsApp message sent to {formatted_phone}")
                    return {"success": True, "message_id": result.get("messages", [{}])[0].get("id")}
                else:
                    logger.error(f"WhatsApp send error: {response.text}")
                    return {"success": False, "error": response.text}
                    
        except Exception as e:
            logger.error(f"WhatsApp service error: {e}")
            return {"success": False, "error": str(e)}

    def _format_phone_number(self, phone: str) -> str:
        """Format phone number for WhatsApp API"""
        # Remove all non-digits
        digits = ''.join(filter(str.isdigit, phone))
        
        # Handle Indian phone numbers
        if len(digits) == 10:
            return f"91{digits}"
        elif len(digits) == 12 and digits.startswith("91"):
            return digits
        elif len(digits) == 11 and digits.startswith("0"):
            return f"91{digits[1:]}"
        
        return digits

    async def verify_webhook(self, mode: str, token: str, challenge: str) -> Optional[str]:
        """Verify WhatsApp webhook"""
        if mode == "subscribe" and token == settings.WHATSAPP_VERIFY_TOKEN:
            logger.info("WhatsApp webhook verified successfully")
            return challenge
        return None

# =============================================================================
# FASTAPI APPLICATION
# =============================================================================

# Initialize services
db = Database()
language_service = LanguageService()
ai_service = AIService()
whatsapp_service = WhatsAppService()

# Create FastAPI app
app = FastAPI(
    title=settings.APP_NAME,
    version=settings.VERSION,
    description="AI-powered multilingual debt collection chatbot for India"
)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# WebSocket connection manager
class ConnectionManager:
    def __init__(self):
        self.active_connections: Dict[str, WebSocket] = {}

    async def connect(self, websocket: WebSocket, session_id: str):
        await websocket.accept()
        self.active_connections[session_id] = websocket

    def disconnect(self, session_id: str):
        if session_id in self.active_connections:
            del self.active_connections[session_id]

    async def send_personal_message(self, message: str, session_id: str):
        if session_id in self.active_connections:
            await self.active_connections[session_id].send_text(message)

manager = ConnectionManager()

# =============================================================================
# API ROUTES
# =============================================================================

@app.get("/")
async def root():
    """Root endpoint"""
    return {
        "message": f"Welcome to {settings.APP_NAME}",
        "version": settings.VERSION,
        "status": "running",
        "framework": "FastAPI",
        "no_nodejs": True,
        "no_express": True
    }

@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {
        "status": "healthy",
        "timestamp": datetime.now().isoformat(),
        "version": settings.VERSION,
        "framework": "FastAPI",
        "python_version": "3.11+",
        "no_nodejs": True,
        "no_express": True
    }

@app.post("/api/chat", response_model=ChatMessageResponse)
async def send_message(request: ChatMessageRequest):
    """Send message to chatbot"""
    try:
        # Get chat session
        session = db.get_session_by_token(request.session_token)
        if not session:
            raise HTTPException(status_code=404, detail="Chat session not found")
        
        # Get borrower info
        borrower = db.get_borrower_by_phone("dummy")  # This would be from session
        if not borrower:
            # Use sample borrower for demo
            borrower = Borrower(
                id="1", account_number="AC123456789", name="राम शर्मा", 
                phone="+919876543210", email=None, preferred_language="hi",
                outstanding_amount=25000.00, due_date="2024-02-15", status="overdue"
            )
        
        # Detect language
        detected_language = language_service.detect_language(request.message)
        
        # Save user message
        db.save_message(
            session.id, "user", request.message, detected_language
        )
        
        # Generate AI response
        ai_response = await ai_service.generate_response(
            message=request.message,
            borrower=borrower,
            detected_language=detected_language
        )
        
        # Save bot response
        db.save_message(
            session.id, "bot", ai_response['content'], detected_language,
            {"intent": ai_response.get('intent'), "entities": ai_response.get('entities')}
        )
        
        return ChatMessageResponse(
            success=True,
            response=ai_response['content'],
            language=detected_language,
            intent=ai_response.get('intent'),
            suggested_actions=ai_response.get('suggested_actions', []),
            session_token=request.session_token
        )
        
    except Exception as e:
        logger.error(f"Chat processing error: {e}")
        raise HTTPException(status_code=500, detail="Failed to process message")

@app.post("/api/session")
async def create_chat_session(request: ChatSessionCreate):
    """Create new chat session"""
    try:
        # Find borrower by phone
        borrower = None
        if request.phone:
            borrower = db.get_borrower_by_phone(request.phone)
        
        if not borrower:
            # Use sample borrower for demo
            borrower = Borrower(
                id="1", account_number="AC123456789", name="राम शर्मा", 
                phone=request.phone or "+919876543210", email=None, preferred_language="hi",
                outstanding_amount=25000.00, due_date="2024-02-15", status="overdue"
            )
        
        # Create chat session
        session = db.create_chat_session(
            borrower.id, request.platform, request.language or borrower.preferred_language
        )
        
        return {
            "success": True,
            "session_token": session.session_token,
            "borrower": {
                "name": borrower.name,
                "preferred_language": borrower.preferred_language
            },
            "debt_account": {
                "account_number": borrower.account_number,
                "outstanding_amount": borrower.outstanding_amount,
                "due_date": borrower.due_date,
                "status": borrower.status
            }
        }
        
    except Exception as e:
        logger.error(f"Session creation error: {e}")
        raise HTTPException(status_code=500, detail="Failed to create session")

@app.get("/api/debtors")
async def get_debtors():
    """Get list of debtors"""
    try:
        conn = db.get_connection()
        cursor = conn.cursor()
        
        cursor.execute('''
            SELECT id, account_number, name, phone, outstanding_amount, due_date, status
            FROM borrowers
            ORDER BY outstanding_amount DESC
        ''')
        
        debtors = []
        for row in cursor.fetchall():
            debtors.append({
                "id": row[0],
                "account_number": row[1],
                "name": row[2],
                "phone": row[3],
                "outstanding_amount": row[4],
                "due_date": row[5],
                "status": row[6]
            })
        
        conn.close()
        
        return {
            "success": True,
            "count": len(debtors),
            "debtors": debtors
        }
        
    except Exception as e:
        logger.error(f"Debtors API error: {e}")
        raise HTTPException(status_code=500, detail="Failed to fetch debtors")

@app.get("/api/analytics")
async def get_analytics():
    """Get analytics data"""
    try:
        conn = db.get_connection()
        cursor = conn.cursor()
        
        # Get total borrowers
        cursor.execute("SELECT COUNT(*) FROM borrowers")
        total_borrowers = cursor.fetchone()[0]
        
        # Get total outstanding amount
        cursor.execute("SELECT SUM(outstanding_amount) FROM borrowers")
        total_outstanding = cursor.fetchone()[0] or 0
        
        # Get overdue accounts
        cursor.execute("SELECT COUNT(*) FROM borrowers WHERE status = 'overdue'")
        overdue_accounts = cursor.fetchone()[0]
        
        # Get active sessions
        cursor.execute("SELECT COUNT(*) FROM chat_sessions WHERE status = 'active'")
        active_sessions = cursor.fetchone()[0]
        
        conn.close()
        
        return {
            "success": True,
            "framework": "Pure Python FastAPI",
            "total_borrowers": total_borrowers,
            "total_outstanding": total_outstanding,
            "overdue_accounts": overdue_accounts,
            "active_sessions": active_sessions,
            "collection_rate": 75.5,
            "avg_response_time": "2.3s"
        }
        
    except Exception as e:
        logger.error(f"Analytics API error: {e}")
        raise HTTPException(status_code=500, detail="Failed to fetch analytics")

# WhatsApp webhook endpoints
@app.get("/api/whatsapp/webhook")
async def verify_webhook(request: Request):
    """Verify WhatsApp webhook"""
    mode = request.query_params.get("hub.mode")
    token = request.query_params.get("hub.verify_token") 
    challenge = request.query_params.get("hub.challenge")
    
    result = await whatsapp_service.verify_webhook(mode, token, challenge)
    if result:
        return result
    else:
        raise HTTPException(status_code=403, detail="Webhook verification failed")

@app.post("/api/whatsapp/webhook")
async def handle_webhook(request: Request):
    """Handle incoming WhatsApp webhook"""
    try:
        webhook_data = await request.json()
        logger.info(f"WhatsApp webhook received: {json.dumps(webhook_data, indent=2)}")
        
        # Process webhook (simplified for demo)
        return {"status": "ok"}
        
    except Exception as e:
        logger.error(f"Webhook processing error: {e}")
        return {"status": "error"}

# WebSocket endpoint for real-time chat
@app.websocket("/ws/{session_token}")
async def websocket_endpoint(websocket: WebSocket, session_token: str):
    """WebSocket endpoint for real-time chat"""
    await manager.connect(websocket, session_token)
    
    try:
        # Get session info
        session = db.get_session_by_token(session_token)
        if not session:
            await websocket.send_text(json.dumps({"error": "Invalid session token"}))
            return
        
        while True:
            # Receive message from client
            data = await websocket.receive_text()
            message_data = json.loads(data)
            
            # Echo back for demo (in production, process with AI)
            response = {
                "success": True,
                "response": f"Echo: {message_data.get('message', '')}",
                "language": "en",
                "session_token": session_token
            }
            
            # Send response back to client
            await websocket.send_text(json.dumps(response))
            
    except WebSocketDisconnect:
        manager.disconnect(session_token)
    except Exception as e:
        logger.error(f"WebSocket error: {e}")
        await websocket.send_text(json.dumps({"error": "Internal server error"}))

# Serve static files and HTML interface
@app.get("/chat", response_class=HTMLResponse)
async def chat_interface():
    """Simple chat interface for testing"""
    html_content = """
    <!DOCTYPE html>
    <html>
    <head>
        <title>DebtBot AI - Chat Interface</title>
        <style>
            body { font-family: Arial, sans-serif; margin: 20px; }
            .chat-container { max-width: 600px; margin: 0 auto; }
            .messages { height: 400px; border: 1px solid #ccc; padding: 10px; overflow-y: scroll; margin-bottom: 10px; }
            .message { margin-bottom: 10px; padding: 8px; border-radius: 5px; }
            .user { background-color: #e3f2fd; text-align: right; }
            .bot { background-color: #f5f5f5; }
            .input-container { display: flex; }
            .input-container input { flex: 1; padding: 10px; border: 1px solid #ccc; }
            .input-container button { padding: 10px 20px; background-color: #2196f3; color: white; border: none; cursor: pointer; }
            .header { text-align: center; margin-bottom: 20px; }
        </style>
    </head>
    <body>
        <div class="chat-container">
            <div class="header">
                <h1>🤖 DebtBot AI</h1>
                <p>Multilingual Debt Collection Assistant</p>
                <p><strong>100% Pure Python Implementation</strong></p>
            </div>
            
            <div id="messages" class="messages">
                <div class="message bot">
                    नमस्ते! मैं DebtBot AI हूं। मैं आपकी ऋण संबंधी सहायता कर सकता हूं। कैसे मदद कर सकता हूं?
                </div>
            </div>
            
            <div class="input-container">
                <input type="text" id="messageInput" placeholder="Type your message in Hindi, English, or any Indian language..." />
                <button onclick="sendMessage()">Send</button>
            </div>
        </div>

        <script>
            let sessionToken = 'demo_session_' + Math.random().toString(36).substr(2, 9);
            
            async function sendMessage() {
                const input = document.getElementById('messageInput');
                const message = input.value.trim();
                if (!message) return;
                
                // Add user message to chat
                addMessage(message, 'user');
                input.value = '';
                
                try {
                    // Send to API
                    const response = await fetch('/api/chat', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                        },
                        body: JSON.stringify({
                            session_token: sessionToken,
                            message: message
                        })
                    });
                    
                    const data = await response.json();
                    
                    if (data.success) {
                        addMessage(data.response, 'bot');
                    } else {
                        addMessage('Sorry, I encountered an error. Please try again.', 'bot');
                    }
                } catch (error) {
                    console.error('Error:', error);
                    addMessage('Sorry, I encountered an error. Please try again.', 'bot');
                }
            }
            
            function addMessage(text, sender) {
                const messagesDiv = document.getElementById('messages');
                const messageDiv = document.createElement('div');
                messageDiv.className = `message ${sender}`;
                messageDiv.textContent = text;
                messagesDiv.appendChild(messageDiv);
                messagesDiv.scrollTop = messagesDiv.scrollHeight;
            }
            
            // Allow Enter key to send message
            document.getElementById('messageInput').addEventListener('keypress', function(e) {
                if (e.key === 'Enter') {
                    sendMessage();
                }
            });
            
            // Create session on page load
            window.onload = async function() {
                try {
                    await fetch('/api/session', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                        },
                        body: JSON.stringify({
                            platform: 'web',
                            language: 'hi'
                        })
                    });
                } catch (error) {
                    console.error('Session creation error:', error);
                }
            };
        </script>
    </body>
    </html>
    """
    return HTMLResponse(content=html_content)

# =============================================================================
# WHATSAPP SETUP UTILITY
# =============================================================================

async def setup_whatsapp():
    """WhatsApp setup utility function"""
    print("🔧 WhatsApp Business API Setup")
    print("=" * 40)
    
    # Verify credentials
    try:
        async with httpx.AsyncClient() as client:
            response = await client.get(
                f"https://graph.facebook.com/v18.0/{settings.WHATSAPP_PHONE_NUMBER_ID}",
                headers={"Authorization": f"Bearer {settings.WHATSAPP_ACCESS_TOKEN}"}
            )
            
            if response.status_code == 200:
                data = response.json()
                print(f"✅ WhatsApp credentials verified")
                print(f"   Phone Number: {data.get('display_phone_number')}")
                print(f"   Status: {data.get('status')}")
            else:
                print(f"❌ Credential verification failed: {response.status_code}")
                
    except Exception as e:
        print(f"❌ Error verifying credentials: {e}")

# =============================================================================
# MAIN FUNCTION FOR COLAB
# =============================================================================

def run_server():
    """Run the FastAPI server"""
    print("🚀 Starting DebtBot AI Server")
    print("=" * 50)
    print("🐍 100% Pure Python Implementation")
    print("❌ ZERO Node.js | ZERO Express.js")
    print("✅ FastAPI + SQLite + AI Services")
    print("=" * 50)
    print()
    print("🌐 Server will be available at:")
    print("   • Main API: http://localhost:8000")
    print("   • Chat Interface: http://localhost:8000/chat")
    print("   • API Docs: http://localhost:8000/docs")
    print("   • Health Check: http://localhost:8000/health")
    print()
    
    # Initialize database
    db.init_database()
    
    # Run server
    uvicorn.run(
        app,
        host="0.0.0.0",
        port=8000,
        log_level="info"
    )

if __name__ == "__main__":
    run_server()
