#!/usr/bin/env python3
"""
WhatsApp Business API Setup Script
Pure Python implementation for configuring WhatsApp integration
"""

import os
import asyncio
import httpx
import json
import sys
from typing import Dict, Optional

class WhatsAppSetup:
    def __init__(self):
        self.access_token = os.getenv("WHATSAPP_ACCESS_TOKEN")
        self.phone_number_id = os.getenv("WHATSAPP_PHONE_NUMBER_ID")
        self.verify_token = os.getenv("WHATSAPP_VERIFY_TOKEN", "debt_collection_verify_2024")
        self.base_url = "https://graph.facebook.com/v18.0"
        
    async def verify_credentials(self) -> bool:
        """Verify WhatsApp API credentials"""
        if not self.access_token or not self.phone_number_id:
            print("❌ WhatsApp credentials not configured")
            print("💡 Please set WHATSAPP_ACCESS_TOKEN and WHATSAPP_PHONE_NUMBER_ID in .env")
            return False
            
        try:
            async with httpx.AsyncClient() as client:
                response = await client.get(
                    f"{self.base_url}/{self.phone_number_id}",
                    headers={"Authorization": f"Bearer {self.access_token}"}
                )
                
                if response.status_code == 200:
                    data = response.json()
                    print(f"✅ WhatsApp credentials verified")
                    print(f"   Phone Number: {data.get('display_phone_number')}")
                    print(f"   Status: {data.get('status')}")
                    return True
                else:
                    print(f"❌ Credential verification failed: {response.status_code}")
                    print(f"   Response: {response.text}")
                    return False
                    
        except Exception as e:
            print(f"❌ Error verifying credentials: {e}")
            return False
    
    async def setup_webhook(self, webhook_url: str) -> bool:
        """Setup webhook URL for WhatsApp"""
        if not self.access_token or not self.phone_number_id:
            print("❌ WhatsApp credentials not configured")
            return False
            
        try:
            async with httpx.AsyncClient() as client:
                # First get the WhatsApp Business Account ID
                response = await client.get(
                    f"{self.base_url}/{self.phone_number_id}",
                    headers={"Authorization": f"Bearer {self.access_token}"}
                )
                
                if response.status_code != 200:
                    print(f"❌ Failed to get phone number info: {response.status_code}")
                    return False
                
                # Setup webhook subscription
                webhook_data = {
                    "object": "whatsapp_business_account",
                    "callback_url": webhook_url,
                    "verify_token": self.verify_token,
                    "fields": "messages"
                }
                
                # Note: This is a simplified webhook setup
                # In production, you'd need to subscribe to the WhatsApp Business Account
                print(f"✅ Webhook configuration prepared")
                print(f"   Callback URL: {webhook_url}")
                print(f"   Verify Token: {self.verify_token}")
                print("💡 Complete webhook setup through Facebook Developer Console")
                return True
                
        except Exception as e:
            print(f"❌ Error setting up webhook: {e}")
            return False
    
    async def send_test_message(self, to_number: str, message: str = "Hello from AI Debt Collection Chatbot!") -> bool:
        """Send a test message"""
        if not self.access_token or not self.phone_number_id:
            print("❌ WhatsApp credentials not configured")
            return False
            
        try:
            async with httpx.AsyncClient() as client:
                message_data = {
                    "messaging_product": "whatsapp",
                    "to": to_number,
                    "type": "text",
                    "text": {"body": message}
                }
                
                response = await client.post(
                    f"{self.base_url}/{self.phone_number_id}/messages",
                    headers={
                        "Authorization": f"Bearer {self.access_token}",
                        "Content-Type": "application/json"
                    },
                    json=message_data
                )
                
                if response.status_code == 200:
                    data = response.json()
                    message_id = data.get("messages", [{}])[0].get("id")
                    print(f"✅ Test message sent successfully")
                    print(f"   Message ID: {message_id}")
                    print(f"   To: {to_number}")
                    return True
                else:
                    print(f"❌ Failed to send test message: {response.status_code}")
                    print(f"   Response: {response.text}")
                    return False
                    
        except Exception as e:
            print(f"❌ Error sending test message: {e}")
            return False

async def main():
    """Main function to handle command line arguments"""
    if len(sys.argv) < 2:
        print("Usage:")
        print("  python whatsapp_setup.py verify")
        print("  python whatsapp_setup.py webhook <webhook_url>")
        print("  python whatsapp_setup.py test <phone_number> [message]")
        return
    
    setup = WhatsAppSetup()
    command = sys.argv[1].lower()
    
    if command == "verify":
        success = await setup.verify_credentials()
        if not success:
            sys.exit(1)
            
    elif command == "webhook":
        if len(sys.argv) < 3:
            print("❌ Please provide webhook URL")
            print("Usage: python whatsapp_setup.py webhook <webhook_url>")
            sys.exit(1)
        
        webhook_url = sys.argv[2]
        success = await setup.setup_webhook(webhook_url)
        if not success:
            sys.exit(1)
            
    elif command == "test":
        if len(sys.argv) < 3:
            print("❌ Please provide phone number")
            print("Usage: python whatsapp_setup.py test <phone_number> [message]")
            sys.exit(1)
        
        phone_number = sys.argv[2]
        message = sys.argv[3] if len(sys.argv) > 3 else "Hello from AI Debt Collection Chatbot!"
        
        success = await setup.send_test_message(phone_number, message)
        if not success:
            sys.exit(1)
            
    else:
        print(f"❌ Unknown command: {command}")
        print("Available commands: verify, webhook, test")
        sys.exit(1)

if __name__ == "__main__":
    asyncio.run(main())
