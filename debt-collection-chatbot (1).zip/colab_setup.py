#!/usr/bin/env python3
"""
Google Colab Setup Script for DebtBot AI
Run this in a Colab cell to install and start the chatbot
"""

import subprocess
import sys
import os

def install_requirements():
    """Install required packages"""
    print("📦 Installing Python packages...")
    
    packages = [
        "fastapi==0.104.1",
        "uvicorn[standard]==0.24.0", 
        "pydantic==2.5.0",
        "pydantic-settings==2.1.0",
        "httpx==0.25.2",
        "googletrans==4.0.0rc1",
        "langdetect==1.0.9",
        "python-multipart==0.0.6",
        "jinja2==3.1.2",
        "python-dotenv==1.0.0"
    ]
    
    for package in packages:
        subprocess.check_call([sys.executable, "-m", "pip", "install", package])
    
    print("✅ All packages installed successfully!")

def setup_environment():
    """Setup environment variables"""
    print("🔧 Setting up environment...")
    
    # Create .env file with sample values
    env_content = """
# AI Debt Collection Chatbot Configuration
# 100% Pure Python FastAPI Implementation

# WhatsApp Business API Configuration
WHATSAPP_ACCESS_TOKEN=EAAIrYgZBTkUsBO4Fi5uTUP2FEhpLKor9wQo6TyplVqZCVBNo8gkzydLq7JDlWGENZAfcG4u6vKTzyJBhMhmSsV9WSubrW6gAsSxZAhsZB5hKzGk4ToWVIJFazEzlYAYLJlSC8sKxsAAXKAFf9JYPMGUhxNCZAO5BobVsrfTDLelvvkk7O5545Mg2AZBiVD8TsOz7ezZC6TZAC7TCiMisnmam4qu196DPut1CYW5ikiZC4wqrusWMsZD
WHATSAPP_PHONE_NUMBER_ID=674138942450620
WHATSAPP_VERIFY_TOKEN=debt_collection_verify_2024

# AI Service Configuration (Optional)
XAI_API_KEY=
GROQ_API_KEY=

# Application Settings
APP_NAME=DebtBot AI
VERSION=1.0.0
DEBUG=True
"""
    
    with open('.env', 'w') as f:
        f.write(env_content)
    
    print("✅ Environment configured!")

def print_instructions():
    """Print usage instructions"""
    print("\n" + "=" * 60)
    print("🎉 DEBTBOT AI SETUP COMPLETED!")
    print("=" * 60)
    print()
    print("🚀 To start the chatbot, run:")
    print("   python main.py")
    print()
    print("🌐 Once started, access:")
    print("   • Chat Interface: http://localhost:8000/chat")
    print("   • API Documentation: http://localhost:8000/docs")
    print("   • Health Check: http://localhost:8000/health")
    print()
    print("💡 Features:")
    print("   ✅ Multilingual support (Hindi, English, Marathi, Tamil, Telugu)")
    print("   ✅ WhatsApp Business API integration")
    print("   ✅ Real-time chat interface")
    print("   ✅ SQLite database for data storage")
    print("   ✅ RBI compliant debt collection")
    print("   ✅ AI-powered responses")
    print()
    print("🐍 100% Pure Python - No Node.js or Express.js!")
    print("=" * 60)

def main():
    """Main setup function"""
    print("🤖 AI DEBT COLLECTION CHATBOT - GOOGLE COLAB SETUP")
    print("🇮🇳 Multilingual Debt Recovery System")
    print("🐍 100% Pure Python Implementation")
    print("=" * 60)
    
    try:
        install_requirements()
        setup_environment()
        print_instructions()
        
    except Exception as e:
        print(f"❌ Setup failed: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()
